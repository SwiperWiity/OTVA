#include "stm32f10x.h"
#include "math.h"
#include "delay.h"
#include "led.h"
#include "uart.h"
#include "oled_s.h"
#include "PWM.h"
#include "PMOS.h"
#include "motor.h"

#define Angle_x_MAX 60
#define Angle_x_MIN (-60)
#define Angle_y_MAX 60
#define Angle_y_MIN (-30)
struct
{
	char Shoot; //射击
	char Turn;	//转向
	char Flag;
} Water;

struct
{
	char LED; //LED	on/off/auto/l/r/w
	char Bee; //BZZ	on/off/auto
	char Flag;
} CarL;

struct
{
	float Angle_x; //x轴   +
	float Angle_y; //y轴
	char Stop;
	char Flag;
	char add;
} Steering_GearS; //舵机

struct
{
	int Auto_x; //x轴   +
	int Auto_y; //y轴
	char Flag;
} OpenMV; //舵机

struct
{
	char Straight; //直线	Forward/back
	char Turn;	   //转向	Left/right
	char Stop;	   //停止	T/F
	char Flag;
	char Straight_1;
	char Straight_2;
	unsigned int Speed_1;
	unsigned int Speed_2;
} Motor = {0, 0, 0, 0, 0, 0, 470, 460};

char Control_Mode = 'S'; //	Auto  Manual  Stop
char Control_Mode_Flag = 1;
char OLED_Show[4][16] = {"     OTVA     ", "   Sterilize   ", "     Ready    ", "  YTY     WQL "}; //max len is 16(g),but you time_Irt confine befor 12(12/4) so,max is 14 (e)
char Key_time;
char array_speed[8] = {"1234"};
char array_num[8];
int n, m,k;

float Magnificationx = 3/8.0;
float Magnificationy = 1/2.0;

void Limber(void);
void Mian_Init(void);
int Steering(float Angle);
unsigned int String_NUM_to_int_NUM(char *Sting, char Length);
void Int_NUM_to_String_NUM(char *array, int num, char Length);
void UART_1_Hanld(void);
void UART_5_Hanld(void);

void OpenMV_Hanlde (void);
void Motor_Drive(void);
void Water_Drive(void);
void CarL_Drive(void);
void Steering_GearS_Drive(void);
int main(void)
{
	Mian_Init();
	UART_Send(UART_1, "{Ready} \r\n");
	UART_Send(UART_5, "{Ready} \r\n");
	delay_ms(100);
	while (1)
	{
		delay_ms(10);
		UART_5_Hanld();
		UART_1_Hanld();
		if (Control_Mode == 'A' && Control_Mode_Flag != 'A') // 自动模式
		{
			Control_Mode_Flag = 'A';
			UART_Send(UART_1, "{OpenMV-on} \r\n");
			LED_RGB('B');
		}
		else if (Control_Mode == 'M' && Control_Mode_Flag != 'M') // 手动模式
		{
			Control_Mode_Flag = 'M';
			UART_Send(UART_1, "{OpenMV-off} \r\n");
			Steering_GearS.Flag = 'Y'; // y轴归位
			Steering_GearS.Angle_y = 0;
			LED_RGB('G');
		}
		else if (Control_Mode == 'S') //	Control_Mode Stop
		{
			if (Control_Mode_Flag)
			{
				UART_Send(UART_1, "{OpenMV-off} \r\n");
				Control_Mode_Flag = 0;
				Steering_GearS.Flag = 'A';	  // 所有舵机
				Steering_GearS.Angle_x = 0;	  // x轴为 0
				Steering_GearS.Angle_y = -60; // y轴为 -60
				Motor.Flag = 'P';			  // 电机停止
				Motor.Stop = 'T';			  // 电机停止
				PMOS_Control(MOS_1, MOS_OFF); // Null
				Water.Flag = 'A';			  // Water ALL
				Water.Shoot = 'F';			  // Water Shoot OFF
				Water.Turn = ' ';			  // Water Turn Rst
				CarL.Flag = 'A';			  // CarL ALL
				CarL.LED = 'F';				  // CarL LED 关灯
				CarL.Bee = 'F';				  // CarL Bee 蜂鸣器关闭
			}
			LED_RGB('R');
		}

		OpenMV_Hanlde ();
		Motor_Drive();
		Water_Drive();
		CarL_Drive();
		Steering_GearS_Drive();
		Clean(sizeof(array_speed), array_speed, 0);
	}
}

void UART_5_Hanld(void)				// 手控
{
	if (UART_Flag.Read_Flag5)
	{
		UART_Flag.Read_Flag5 = 0;
		if (Uart5_array_r[0] == '{')
		{
			if (Uart5_array_r[1] == 'O' && Uart5_array_r[2] == 'T' && Uart5_array_r[3] == 'V' && Uart5_array_r[4] == 'A') //	{OTVA-Auto}   {OTVA-Manual}   {OTVA-Stop}
			{
				if (Uart5_array_r[5] == '-') // 命令		Command
				{
					Control_Mode = Uart5_array_r[6];
				}
				else if (Uart5_array_r[5] == ':') // 指令		Order
				{
					if (Control_Mode == 'M') // Manual
					{
						if (Uart5_array_r[6] == 'W' && Uart5_array_r[7] == 't') // Water
						{
							if (Uart5_array_r[9] == 'o' && Uart5_array_r[10] == 'n') // {OTVA:Wt:on/off /up/down}
							{
								Water.Shoot = 'T';
							}
							else if (Uart5_array_r[9] == 'o' && Uart5_array_r[10] == 'f')
							{
								Water.Shoot = 'F';
							}
							else
								Water.Flag = 'T'; //在 Wt条件下，不是 Shoot 就是 Turn   搓叉赋值

							if (Uart5_array_r[9] == 'u' && Uart5_array_r[10] == 'p')
							{
								Water.Turn = 'U';
							}
							else if (Uart5_array_r[9] == 'd' && Uart5_array_r[10] == 'o')
							{
								Water.Turn = 'D';
							}
							else
								Water.Flag = 'S';
						}

						else if (Uart5_array_r[6] == 'C' && Uart5_array_r[7] == 'l') // 车前灯	Carl
						{
							if (Uart5_array_r[9] == 'L' && Uart5_array_r[10] == 'E' && Uart5_array_r[11] == 'D') // {OTVA:Cl:LED:T/F/A /L/R/W}
							{
								CarL.LED = Uart5_array_r[13];
								CarL.Flag = 'L';
							}
							else if (Uart5_array_r[9] == 'B' && Uart5_array_r[10] == 'e' && Uart5_array_r[11] == 'e') // {OTVA:Cl:Bee:T/F/A}
							{
								CarL.Bee = Uart5_array_r[13];
								CarL.Flag = 'B';
							}
						}

						else if (Uart5_array_r[6] == 'S' && Uart5_array_r[7] == 'g') // 舵机		Steering GearS
						{
							Steering_GearS.Flag = 'X';
							Steering_GearS.Stop = Uart5_array_r[9]; // {OTVA:Sg:T/F}
						}

						else if (Uart5_array_r[6] == 'M' && Uart5_array_r[7] == 't') // 电机		Motor
						{
							Motor.Stop = 'F';
							if (Uart5_array_r[9] == 'W' || Uart5_array_r[9] == 'S' || Uart5_array_r[9] == 'P') // {OTVA:Wt:W/S/P}
							{
								Motor.Flag = 'S';
								Motor.Straight = Uart5_array_r[9];
							}
							else if (Uart5_array_r[9] == 'M' && Uart5_array_r[10] == 'S') // 速度调整
							{
								Motor.Flag = 'S';
								if (Uart5_array_r[12] == 'A')
								{
									if (Uart5_array_r[13] == '+')
									{
										Motor.Speed_1 = Motor.Speed_1 + 10;
									}
									else if (Uart5_array_r[13] == '-')
									{
										Motor.Speed_1 = Motor.Speed_1 - 10;
									}
									else // 数字调速
									{
										Motor.Speed_1 = String_NUM_to_int_NUM(Uart5_array_r, sizeof(Uart5_array_r));
									}
									if (Motor.Speed_1 < 150) // 限速
									{
										Motor.Speed_1 = 150;
									}
									else if (Motor.Speed_1 > 1000)
									{
										Motor.Speed_1 = 1000;
									}
								}
								else if (Uart5_array_r[12] == 'B')
								{
									if (Uart5_array_r[13] == '+')
									{
										Motor.Speed_2 = Motor.Speed_2 + 10;
									}
									else if (Uart5_array_r[13] == '-')
									{
										Motor.Speed_2 = Motor.Speed_2 - 10;
									}
									else
									{
										Motor.Speed_2 = String_NUM_to_int_NUM(Uart5_array_r, sizeof(Uart5_array_r));
									}
									if (Motor.Speed_2 < 150) // 限速
									{
										Motor.Speed_2 = 150;
									}
									else if (Motor.Speed_2 > 800)
									{
										Motor.Speed_2 = 800;
									}
								}
							}
							else // {OTVA:Wt:A/D/M/C}
							{
								Motor.Flag = 'T';
								Motor.Turn = Uart5_array_r[9];
							}
						}
					}
				}
			}
		}
		else{UART_Send(UART_5, "Error !\r\n");}

		Clean(sizeof(Uart5_array_r), Uart5_array_r, 0);
		Clean(sizeof(Uart5_array_s), Uart5_array_s, 0);
	}
}

void UART_1_Hanld(void)				// OpenMV
{
	if (UART_Flag.Read_Flag1)
	{
		UART_Flag.Read_Flag1 = 0;
		if (Control_Mode == 'A')		// EN Auto
		{
			if (Uart1_array_r[0] == '{' && Uart1_array_r[1] == 'M' && Uart1_array_r[2] == 'V')
			{
				if (Uart1_array_r[4] == 'x')
				{
					OpenMV.Auto_x = String_NUM_to_int_NUM(Uart1_array_r, sizeof(Uart1_array_r));
				}
				else if (Uart1_array_r[4] == 'y')
				{
					OpenMV.Auto_y = String_NUM_to_int_NUM(Uart1_array_r, sizeof(Uart1_array_r));
				}
				OpenMV.Flag = 'T';
			}
		}
		Clean(sizeof(Uart1_array_r), Uart1_array_r, 0);
		Clean(sizeof(Uart1_array_s), Uart1_array_s, 0);
	}
}

void OpenMV_Hanlde (void)
{
	if(OpenMV.Flag == 'T')
	{
		OpenMV.Flag = 'F';
		if (OpenMV.Auto_x < 150)							// It's not in the middle
		{
			Steering_GearS.Angle_x -= 0.5;
			// Motor.Flag = 'T';
			// Motor.Turn = Uart5_array_r[9];
			if (OpenMV.Auto_x < 120)
			{
				Steering_GearS.Angle_x -= 1.5;
			}
		}
		else if (OpenMV.Auto_x > 170)
		{
			Steering_GearS.Angle_x += 0.5;
			if (OpenMV.Auto_x >200)
			{
				Steering_GearS.Angle_x += 1.5;
			}
		}

		if (OpenMV.Auto_y < 110)							// Y
		{
			Steering_GearS.Angle_y += 0.5;
		}
		else if (OpenMV.Auto_y > 130)
		{
			Steering_GearS.Angle_y -= 0.5;
		}
		Water.Flag = 'T';
		if (Steering_GearS.Angle_y > 20)
		{
			Water.Turn = 'U';
		}
		else if (Steering_GearS.Angle_y < -15)
		{
			Water.Turn = 'D';
		}
		else	Water.Turn = ' ';

		Steering_GearS.Flag = 'A';
	}
}

void Steering_GearS_Drive(void)
{
	if (Steering_GearS.Stop == 'F')
	{
		if (Steering_GearS.add == '+')
		{
			Steering_GearS.Angle_x++;
			if (Steering_GearS.Angle_x > 60)
				Steering_GearS.add = '-';
		}
		else
		{
			Steering_GearS.Angle_x--;
			if (Steering_GearS.Angle_x < -60)
				Steering_GearS.add = '+';
		}
		Steering_GearS.Flag = 'X';
		delay_ms(10);
	}
	if (Steering_GearS.Flag == 'X' || Steering_GearS.Flag == 'A')
	{
		if (Steering_GearS.Angle_x > Angle_x_MAX)
			Steering_GearS.Angle_x = Angle_x_MAX; // Angle_x MAX
		if (Steering_GearS.Angle_x < Angle_x_MIN)
			Steering_GearS.Angle_x = Angle_x_MIN; // Angle_x MAX
		TIM_SetCompare3(TIM4, Steering(-Steering_GearS.Angle_x));
	}
	if (Steering_GearS.Flag == 'Y' || Steering_GearS.Flag == 'A')
	{
		if (Steering_GearS.Angle_y > Angle_y_MAX)
			Steering_GearS.Angle_y = Angle_y_MAX;
		if (Steering_GearS.Angle_y < Angle_y_MIN)
			Steering_GearS.Angle_y = Angle_y_MIN;
		TIM_SetCompare4(TIM4, Steering(Steering_GearS.Angle_y));
	}
	Steering_GearS.Flag = 0;
}

unsigned int String_NUM_to_int_NUM(char *Sting, char Length)
{
	unsigned int num = 0;
	char dat, timer, Init = '0'; // 从 array[Init] 开始，到 array[Init+m] 都是需要转换的数字
	char m = 0;					 // 字符串中 连续数字的个数
	if (Length > 30)
	{
		Length = 30;
	}
	for (n = 0; n < Length; n++)
	{
		dat = *(Sting + n);
		if (dat >= '0' && dat <= '9')
		{
			m++;
			if (Init == '0') //读取开始为数字的 n位
			{
				Init = n;
			}
		}
		else if (m > 0)
			break; // 当m不为零，且dat不为数字时，退出
	}
	if (Init != '0')
	{
		timer = m + Init; // Init 头		timer 尾
		for (n = Init; n < timer; n++)
		{
			dat = *(Sting + n);
			num = num * 10 + (dat - '0');
		}
	}
	return num;
}

void Int_NUM_to_String_NUM(char *array, int num, char Length)
{
	int Multiple = 1;
	if (Length > 5)
	{
		return;
	}
	for (n = 0; n < Length - 1; n++)
	{
		Multiple = Multiple * 10;
	}
	for (n = 0; n < Length; n++)
	{
		*(array + n) = (num / Multiple) % 10 + '0';
		Multiple = Multiple / 10;
	}
	*(array + n) = '*';
	*(array + n + 1) = '}';
}

void Motor_Drive(void)
{
	int MSpeed1, MSpeed2; // 临时数据
	if (Motor.Stop == 'F')
	{
		MSpeed1 = Motor.Speed_1;
		MSpeed2 = Motor.Speed_2;
		if (Motor.Flag == 'S' || Motor.Flag == 'A')
		{
			if (Motor.Straight == 'W') // 进
			{
				Motor.Straight_1 = 'L';
				Motor.Straight_2 = 'L';
			}
			else if (Motor.Straight == 'S') // 退
			{
				Motor.Straight_1 = 'R';
				Motor.Straight_2 = 'R';
			}
			else if (Motor.Straight == 'P') // 停
			{
				Motor.Stop = 'T';
			}
		}
		if (Motor.Flag == 'T' || Motor.Flag == 'A')
		{
			if (Motor.Turn == 'A')
			{
				MSpeed1 /= 2;
			}
			else if (Motor.Turn == 'D')
			{
				MSpeed2 /= 2;
			}
			else if (Motor.Turn == 'M')
			{
			}
			else if (Motor.Turn == 'C') //	circle 圆
			{
				MSpeed1 = 360;
				MSpeed2 = 360;
				Motor.Straight_1 = 'L';
				Motor.Straight_2 = 'R';
			}
		}
	}
	if (Motor.Stop == 'T')
	{
		MSpeed1 = 0;
		MSpeed2 = 0;
	}
	if (Motor.Flag != ' ')
	{
		MotorX_Control(Motor1, Motor.Straight_1, MSpeed1);
		MotorX_Control(Motor2, Motor.Straight_2, MSpeed2);

		array_speed[0] = '{';
		array_speed[1] = '*';
		array_speed[2] = 'A';
		Int_NUM_to_String_NUM(&array_speed[3], MSpeed1, 4);
		UART_Send(UART_5, array_speed);
		delay_ms(10);
		array_speed[2] = 'B';
		Int_NUM_to_String_NUM(&array_speed[3], MSpeed2, 4);
		UART_Send(UART_5, array_speed);
		Motor.Flag = ' ';
	}
}

int Steering(float Angle) //舵机角度计算
{
	static float Angle_float = 10 / 9.0;
	int Time_PWM;
	Time_PWM = (Angle * Angle_float) + 150;
	return Time_PWM;
}

void Water_Drive(void) // Water
{
	if (Water.Flag == 'S' || Water.Flag == 'A')
	{
		if (Water.Shoot == 'T')
		{
			PMOS_Control(MOS_2, MOS_ON);
		}
		else if (Water.Shoot == 'F')
		{
			PMOS_Control(MOS_2, MOS_OFF);
		}
	}
	if (Water.Flag == 'T' || Water.Flag == 'A') // Turn
	{
		if (Water.Turn == 'U')
		{
			TIM_SetCompare1(TIM5, Steering(-20));
		}
		else if (Water.Turn == 'D')
		{
			TIM_SetCompare1(TIM5, Steering(15));
		}
		else
		{
			TIM_SetCompare1(TIM5, Steering(0));
		}
	}
	Water.Flag = 0;
}

void CarL_Drive(void)
{
	if (CarL.Flag == 'L' || CarL.Flag == 'A')
	{
		if (CarL.LED == 'T') //开灯
		{
			UART_Send(UART_2, "{\"CarL\":LED:on}");
		}
		else if (CarL.LED == 'F') //关灯
		{
			UART_Send(UART_2, "{\"CarL\":LED:of}");
		}
		else if (CarL.LED == 'A') //自动灯
		{
			UART_Send(UART_2, "{\"CarL\":LED:auto}");
		}
		else if (CarL.LED == 'L') //左转灯
		{
			UART_Send(UART_2, "{\"CarL\":LED:l}");
		}
		else if (CarL.LED == 'R') //右转灯
		{
			UART_Send(UART_2, "{\"CarL\":LED:r}");
		}
		else if (CarL.LED == 'W') //取消转向灯
		{
			UART_Send(UART_2, "{\"CarL\":LED:w}");
		}
	}
	if (CarL.Flag == 'B' || CarL.Flag == 'A')
	{
		delay_ms(500);
		if (CarL.Bee == 'T') //Bee on
		{
			UART_Send(UART_2, "{\"CarL\":Bee:on}");
		}
		else if (CarL.Bee == 'F') //Bee off
		{
			UART_Send(UART_2, "{\"CarL\":Bee:of}");
		}
		else if (CarL.Bee == 'A') //Bee auto
		{
			UART_Send(UART_2, "{\"CarL\":Bee:auto}");
		}
	}
	CarL.Flag = 0;
}

void Mian_Init(void)
{
	delay_init();
	OLED_Init();
	OLED_ShowString(0, 0, OLED_Show[0]);
	OLED_ShowString(0, 2, OLED_Show[1]);
	OLED_ShowString(0, 4, OLED_Show[2]);
	OLED_ShowString(0, 6, OLED_Show[3]);

	//	KEY_GPIO_Init ();
	//	do{
	//			if(KEY_Read() == 'T') Key_time++;
	//			else Key_time = 0;
	//			delay_ms(10);
	//	}while(Key_time < 10);					//Un locking

	LED_GPIO_Init();
	MotorX_Init(Motor1);
	MotorX_Init(Motor2);
	PMOS_Init();
	Limber();

	PMOS_Control(MOS_1, MOS_ON);
	MotorX_Control(Motor1, 'l', 0); //左	<-
	MotorX_Control(Motor2, 'l', 0); //右	->
	Clean(16, OLED_Show[1], MotorX_Control(Motor4, 'r', 330));
	delay_ms(1000);
	UART_Init(UART_1, 115200);
	UART_Init(UART_2, 9600);
	UART_Init(UART_5, 115200);
}

void Limber(void) // 热身
{
	TIM2_PWM_Init(1999, 719);
	TIM4_PWM_Init(1999, 719); //20ms pwm  20ms 1.5ms (0) 0.5ms (-90) 2.5ms (+90)
	TIM5_PWM_Init(1999, 719);
	TIM_SetCompare1(TIM5, Steering(0)); //y
	TIM_SetCompare2(TIM5, Steering(0)); //y
	TIM_SetCompare1(TIM2, Steering(0));
	TIM_SetCompare2(TIM2, Steering(0));
	TIM_SetCompare3(TIM4, Steering(0)); //x
	TIM_SetCompare4(TIM4, Steering(0)); //y
	delay_ms(100);
	for (n = 0; n < 45; n++)
	{
		TIM_SetCompare3(TIM4, Steering(n));
		TIM_SetCompare4(TIM4, Steering(n));
		delay_ms(20);
	}
	for (n = 45; n > -30; n--)
	{
		TIM_SetCompare3(TIM4, Steering(n)); // x
		TIM_SetCompare4(TIM4, Steering(n)); // y
		delay_ms(20);
	}
	TIM_SetCompare3(TIM4, Steering(0));
	TIM_SetCompare4(TIM4, Steering(0));
	TIM_SetCompare1(TIM5, Steering(0));
}
