#ifndef _code_handle_h
#define _code_handle_h

void Code_Replace (char Length,char Origin,char *target,const char *array);

#endif
