#ifndef _PWM_H_
#define _PWM_H_

#include "sys.h"
void TIM2_PWM_Init(u16 arr, u16 psc);
void TIM4_PWM_Init (u16 arr,u16 psc);
void TIM5_PWM_Init(u16 arr, u16 psc);
void TIM8_PWM_Init (u16 arr,u16 psc);

#endif
