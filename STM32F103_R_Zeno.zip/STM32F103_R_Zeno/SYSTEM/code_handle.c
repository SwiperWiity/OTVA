#include "code_handle.h"

void Code_Replace (char Length,char Origin,char *target,const char *array)
{
    char n;
    for(n = 0;n < Length;n++)
    {
        *(target + Origin + n) = *(array + n);
    }
}
