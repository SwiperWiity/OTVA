#include "PMOS.h"

void PMOS_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure); //
	
	GPIO_ResetBits(GPIOA,GPIO_Pin_6|GPIO_Pin_7);		//默认关闭
}

void PMOS_Control(char channel,char order)
{
	switch (channel)
	{
		case MOS_1:
		{
			if(order == 0)	GPIO_ResetBits(GPIOA,GPIO_Pin_6);
			else GPIO_SetBits(GPIOA,GPIO_Pin_6);
			break;
		}
		case MOS_2:
		{
			if(order == 0)	GPIO_ResetBits(GPIOA,GPIO_Pin_7);
			else GPIO_SetBits(GPIOA,GPIO_Pin_7);
			break;
		}
		 default :break;
	}
}
