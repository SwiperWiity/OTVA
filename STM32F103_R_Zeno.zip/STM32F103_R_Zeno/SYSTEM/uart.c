#include "uart.h"

char Uart1_array_r[24];
char Uart1_array_s[24];

char Uart2_array_r[24];
char Uart2_array_s[24];

char Uart5_array_r[24];
char Uart5_array_s[24];

	char r1_num;
	char r2_num;
	char r3_num;
	char r4_num;
	char r5_num;

char array[8];
static int n;
Read_Flag UART_Flag;

void UART_Init(char Channel, uint32_t Baud)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure; //
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //设置中断组，4位抢占优先级，4位响应优先级

	if (Channel == 1)
	{
		/*	Clock	*/
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  // GPIOB 服用 PB6 PB7
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE); // USART1  (APB2)
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);   //重映射时钟开启
		GPIO_PinRemapConfig(GPIO_Remap_USART1, ENABLE);
		USART_DeInit(USART1);

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; //TXD
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //
		GPIO_Init(GPIOB, &GPIO_InitStructure);
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;	  //RXD
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //
		GPIO_Init(GPIOB, &GPIO_InitStructure);

		USART_InitStructure.USART_BaudRate = Baud;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //
		USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;					//
		USART_InitStructure.USART_Parity = USART_Parity_No;								//
		USART_InitStructure.USART_StopBits = USART_StopBits_1;							//
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;						//
		USART_Init(USART1, &USART_InitStructure);
		USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); //
		USART_Cmd(USART1, ENABLE);					   //

		NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; //抢占优先级
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		  //响应优先级
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);
	}
	else if (Channel == 2)
	{
		// 外设使能时钟
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
		USART_DeInit(USART2); //复位串口2 -> 可以没有

		// 初始化 串口对应IO口  TX-PA2  RX-PA3
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //TXD
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3; //RXD
		GPIO_Init(GPIOA, &GPIO_InitStructure);

		// 初始化 串口模式状态
		USART_InitStructure.USART_BaudRate = Baud;										// 波特率
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // 硬件流控制
		USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;					// 发送 接收 模式都使用
		USART_InitStructure.USART_Parity = USART_Parity_No;								// 没有奇偶校验
		USART_InitStructure.USART_StopBits = USART_StopBits_1;							// 一位停止位
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;						// 每次发送数据宽度为8位
		USART_Init(USART2, &USART_InitStructure);

		USART_Cmd(USART2, ENABLE);					   //使能串口
		USART_ITConfig(USART2, USART_IT_RXNE, ENABLE); //开启接收中断

		// 初始化 中断优先级
		NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; //抢占优先级
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		  //响应优先级
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);
	}

	else if (Channel == 5)
	{
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD, ENABLE);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;		//UART5 TX；
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //复用推挽输出；
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOC, &GPIO_InitStructure);
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;			  //UART5 RX；
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //浮空输入
		GPIO_Init(GPIOD, &GPIO_InitStructure);

		USART_InitStructure.USART_BaudRate = Baud;										// 波特率
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // 硬件流控制
		USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;					// 发送 接收 模式都使用
		USART_InitStructure.USART_Parity = USART_Parity_No;								// 没有奇偶校验
		USART_InitStructure.USART_StopBits = USART_StopBits_1;							// 一位停止位
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;						// 每次发送数据宽度为8位
		USART_Init(UART5, &USART_InitStructure);										//配置串口参数

		NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn;		  //中断号
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; //抢占优先级
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;		  //响应优先级
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStructure);

		USART_ITConfig(UART5, USART_IT_RXNE, ENABLE); //开启接收中断
		USART_Cmd(UART5, ENABLE);					  //使能串口
	}
}

void UART_Send(char Channel, char *String)
{
	n = 0;
	while (30 - n)
	{
		switch (Channel)
		{
		case 1:
			while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
				;
			USART_SendData(USART1, *(String + n));
			break;
		case 2:
			while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET)
				;
			USART_SendData(USART2, *(String + n));
			break;
		case 3:
			while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET)
				;
			USART_SendData(USART3, *(String + n));
			break;
		case 4:
			while (USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET)
				;
			USART_SendData(UART4, *(String + n));
			break;
		case 5:
			while (USART_GetFlagStatus(UART5, USART_FLAG_TC) == RESET)
				; //USART_FLAG_TXE 寄存器空标志位，USART_FLAG_TC 硬件 TXD IO结束 标志位
			USART_SendData(UART5, *(String + n));
			break;
		default:
			break;
		}
		if (*(String + n) == '\n' || *(String + n) == 0)
			return;
		n++;
	}
}

void Clean(unsigned char Length, char *Opinter, char *dat)
{
	for (n = 0; n < Length; n++)
	{
		*(Opinter + n) = *dat++;
	}
}

char *Num_Handle_Byte(char num)
{
	for (n = 0; n <= 7; n++)
	{
		if (0x80 & (num << n))
			array[n] = '1';
		else
			array[n] = '0';
	}
	return array;
}

void USART1_IRQHandler (void) //中断处理函数；
{
	char res;
	if(USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
	{
		USART_ClearFlag(USART1, USART_IT_RXNE);
		if (UART_Flag.Read_Flag1 == 0)
		{
			res = USART_ReceiveData(USART1); //接收数据
			Uart1_array_r[r1_num ++] = res;
			if (res == '}')
			{
				UART_Flag.Read_Flag1 = 1;
				r1_num = 0;
			}
		}
	}
}

void USART2_IRQHandler(void) // (Read_Flag)
{
	char res;
	if (USART_GetITStatus(USART2, USART_IT_RXNE)) //判断是否发生中断；
	{
		USART_ClearFlag(USART2, USART_IT_RXNE); //清除标志位
		if (UART_Flag.Read_Flag2 == 0)
		{
			res = USART_ReceiveData(USART2); //接收数据
			Uart2_array_r[r2_num++] = res;
			if (res == '\n' || res == '}')
			{
				UART_Flag.Read_Flag2 = 1;
				r2_num = 0;
			}
		}
	}
}

void UART5_IRQHandler(void) //中断处理函数；
{
	char res;
	if (USART_GetITStatus(UART5, USART_IT_RXNE)) //判断是否发生中断；
	{
		USART_ClearFlag(UART5, USART_IT_RXNE); //清除标志位
		if (UART_Flag.Read_Flag5 == 0)
		{
			res = USART_ReceiveData(UART5); //接收数据
			Uart5_array_r[r5_num++] = res;
			if (res == '}')
			{
				UART_Flag.Read_Flag5 = 1;
				r5_num = 0;
			}
		}
	}
}
