#ifndef _UART_H_
#define _UART_H_

#include "stm32f10x_rcc.h"

#define UART_1 1
#define UART_2 2
#define UART_3 3
#define UART_4 4
#define UART_5 5

typedef struct 
{
	char Read_Flag1;
	char Read_Flag2;
	char Read_Flag3;
	char Read_Flag4;
	char Read_Flag5;
} Read_Flag;

extern Read_Flag UART_Flag;
extern char Uart5_array_r[24];
extern char Uart5_array_s[24];

extern char Uart2_array_r[24];
extern char Uart2_array_s[24];

extern char Uart1_array_r[24];
extern char Uart1_array_s[24];

void UART_Init (char Channel,uint32_t Baud);
void UART_Send(char Channel,char *String);
char *  Num_Handle_Byte (char num);
void Clean(unsigned char Length,char *Opinter,char *dat);

#endif
